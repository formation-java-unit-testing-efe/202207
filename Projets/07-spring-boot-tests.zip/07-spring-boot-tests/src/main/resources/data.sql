DROP TABLE IF EXISTS Personne;
 
CREATE TABLE Personne (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  prenom VARCHAR(255) NOT NULL,
  nom VARCHAR(255) NOT NULL,
  age INT DEFAULT 0
);
 
INSERT INTO Personne (nom, prenom, age) VALUES
  ('Lebleu', 'Anne', 42),
  ('Levert', 'Marc', 35),
  ('Lerouge', 'Hedgar', 65);