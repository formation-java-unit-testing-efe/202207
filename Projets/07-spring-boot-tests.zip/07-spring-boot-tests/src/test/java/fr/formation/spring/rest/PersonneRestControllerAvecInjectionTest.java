	package fr.formation.spring.rest;
	
	import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;

import fr.formation.spring.bll.PersonneManager;
import fr.formation.spring.entity.Personne;
	
	@SpringBootTest(classes = {PersonneRestController.class})
	public class PersonneRestControllerAvecInjectionTest {
	
		@Autowired
		PersonneRestController prc;
		
		@MockBean
		PersonneManager pm;
		
	
		@Test
		public void testPersonnePasTrouvee() throws Exception {
			Optional<Personne> op = Optional.empty();
			when(pm.trouver(anyInt())).thenReturn(op);
			
			ResponseEntity<Personne> retour = prc.getPersonne(1);
	        
			assertTrue(retour.getStatusCode().is4xxClientError());
	 	}
	
		
	}

	