package fr.formation.spring.bll;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import fr.formation.spring.dal.LivreDao;
import fr.formation.spring.entity.Livre;


@ExtendWith(MockitoExtension.class)
public class LivreManagerTest {

	@InjectMocks
	private LivreManager lm;
	
	@Mock
	private LivreDao lDao;
	
	
	
	@Captor
	private ArgumentCaptor<Livre> captor;
	
	
	
	
	@Test
	void testAjoutLivreNul() {
		assertThrows(Exception.class, () -> lm.ajout(null));
	}
	
	@Test
	void testAjoutLivrePasNul() {
		Livre l = new Livre();
		assertDoesNotThrow(() -> lm.ajout(l));
		Mockito.verify(lDao).save(captor.capture());
		assertSame(l, captor.getValue());
	}
	
	@Test
	void testTrouverLivreNonPresent() {
		Mockito.when(lDao.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		assertNull(lm.trouver(4));
	}
	
	@Test
	void testTrouverLivrePresent() {
		Mockito.when(lDao.findById(Mockito.anyInt())).thenReturn(Optional.of(new Livre()));
		assertNotNull(lm.trouver(4));
	}
	

}
