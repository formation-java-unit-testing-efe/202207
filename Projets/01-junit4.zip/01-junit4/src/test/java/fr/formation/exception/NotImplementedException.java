package fr.formation.exception;

public class NotImplementedException extends RuntimeException {

}
