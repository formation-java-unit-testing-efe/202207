package fr.formation.service;



import static org.junit.Assert.assertThat;

import org.assertj.core.api.Assertions;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import fr.formation.model.Personne;

public class AssertThatTest {

	
	@Test
	public void testHamcrest() {
		String chaine = "ABC";
		String attendu = "abc";
		
		assertThat(chaine.toLowerCase(), CoreMatchers.is(attendu));
	}	
	
	
	@Test
	public void testHamcrestContains() {
		String chaine = "ABC";
		String attendu = "b"; 
		
		assertThat(chaine.toLowerCase(), CoreMatchers.containsString(attendu));
	}
	
	@Test
	public void testEgaliteString() {
		String chaine1 = new String ("A");
		String chaine2 = new String ("A");
		
		Assertions
			.assertThat(chaine1)
			.isEqualTo(chaine2);
	}
	
	
	@Test
	public void testEgalitePersonne() {
		Personne attendu = new Personne("Legrand", "Suzon", 44);
		Personne actual = new Personne("Legrand", "Suzon", 44);
		Assertions
			.assertThat(actual)
			.isEqualTo(attendu);
	}
	
	@Test
	public void testEgalitePersonneSurAttributs() {
		Personne attendu = new Personne("Legrand", "Suzon", 44);
		Personne actual = new Personne("Legrand", "Suzon", 45);
		Assertions
			.assertThat(actual)
			.usingRecursiveComparison() // reflexion
	//		.ignoringFields("age")
			.isEqualTo(attendu);
	}
	
}
