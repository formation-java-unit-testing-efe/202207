package fr.formation.service;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CycleDeVieTest {

	// Lancement du runner de JUnit : main qui prend en parametre une ou plusieurs classes de test
	// Junit charge en mémoire cette classe de test et récupère la liste des méthodes de test
	// Junit boucle pour chaque méthode à test
	// Creation d'une instance de la classe de test puis appelle de LA méthode sur l'objet
	
	
	private static Traitement traitement;
	
	
	@BeforeClass
	public static void beforeClass() {
		System.out.println("@BeforeClass");
		traitement = new Traitement();
	}
	
	@Before
	public void setup() {
		System.out.println("   @Before");
		

	}	
	
	@After
	public void after() {
		System.out.println("   @After");
		traitement = null;

	}
	
//	public CycleDeVieTest() {
//		System.out.println("CycleDeVieTest");
//	}
	
	
	@Test
	public void test1() {
		System.out.println("      test1");
		traitement.addition(4, 7);
	}
	
	
	@Test
	public void test2() {
		System.out.println("      test2");
	
	}
}
