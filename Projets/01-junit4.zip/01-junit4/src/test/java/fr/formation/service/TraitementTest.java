package fr.formation.service;

import static org.junit.Assert.*;

import org.junit.Test;

import fr.formation.exception.OperationException;

public class TraitementTest {

	@Test
	public void testFonction() {
		Traitement traitement = new Traitement();
		fail("Not yet implemented");
	}

	
	@Test
	public void testDivision() {
		double a = 1.0;
		double b = 3.0;
		double attendu = 0.3333333;
		
		Traitement traitement = new Traitement();
		double actual = traitement.division(a, b);
		
		assertEquals(attendu, actual, 0.0000001);
	}
	
	
	@Test(expected = OperationException.class)
	public void testDivisionParZero() throws OperationException {
		Traitement traitement = new Traitement();
		traitement.division(4.2, 0.0);
		
	}
}
