package fr.formation.exception;

public class OperationException extends RuntimeException{

	public OperationException(String msg) {
		super(msg);
	}
}
