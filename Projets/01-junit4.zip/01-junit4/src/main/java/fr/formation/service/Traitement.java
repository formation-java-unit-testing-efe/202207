package fr.formation.service;

import fr.formation.exception.OperationException;

public class Traitement {
		
	public int fonction() {
		return 1;
	}

	
	public double addition(double a, double b) {
		return a + b;
	}
	
	public double division(double a, double b) throws OperationException {
		
		if (b == 0.0)
			throw new OperationException("Division par zero");
		
		return a / b;
	}
	
}
