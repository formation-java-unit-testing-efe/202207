package fr.formation;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Random;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Test;

public class DeBaseTest {
	
	
	private static int total = 0;
	
	
	void premierTest() {
		
		assertEquals(5, 3 + 2);
	}
	
	@BeforeEach
	void setUp() {
		System.out.println("setUp");
	}
	
	@RepeatedTest(10)
	void monRepeatedTest(RepetitionInfo info) {
		
		int val = new Random().nextInt(100);
		
		total += val;
		
		if (info.getCurrentRepetition() == info.getTotalRepetitions()) {
			System.out.println("total : " + total);
			System.out.println("Moyenne: " + ((double) total / info.getTotalRepetitions()));
		}
	}
	
	@Test
	void premierTestQuifail() {
		
		assertEquals(4, 3 + 2, () -> "Ceci est une message d'erreur");
	}

}
