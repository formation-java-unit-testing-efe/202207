package fr.formation;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class TestExceptions {

	
	@Test
	void testDivisionParZero() {
		RuntimeException re = assertThrows(RuntimeException.class, () -> division(4.0, 0.0));
		assertEquals("Division par zero", re.getMessage());
	}
	
	@Test
	void testDivisionPasParZero() {
		assertEquals(4.0, division(12.0, 3.0), 0.001);
	}
	
	@Test
	void testDivisionPasParZeroPasDExceptionLevee() {
		assertDoesNotThrow(() -> division(4.0, 3.0));
	}
	
	
	private double division(double a, double b) throws RuntimeException {
		
		if (b == 0.0)
			throw new RuntimeException("Division par zero");
		
		return a / b;
	}
}
