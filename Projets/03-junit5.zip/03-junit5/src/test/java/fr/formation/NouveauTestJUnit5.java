package fr.formation;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class NouveauTestJUnit5 {

	
	
	@Test
	
	void testPremier() {
		
		assertEquals(null, 0, 0, 0);
	}
}
