package fr.formation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;


@DisplayName("Test de la classe Assymptions faite CGI")
public class AssumptionsTest {

	
	@Test
	@EnabledOnOs(value = OS.WINDOWS)
	void testQueSousWin() {
		System.out.println("Windows");
	}
	
	@Test
	@EnabledOnOs(value = OS.MAC)
	void testQueSousMac() {
		System.out.println("Mac");
	}
	
	@Test
	@DisabledOnOs({OS.AIX, OS.LINUX, OS.MAC})
	void testPasSystemUnix() {
		System.out.println("Pas systeme UNIX");
	}
	
	@Test
	@EnabledOnJre(value = JRE.JAVA_8)
	void testJava8() {
		System.out.println("Java 8");
	}
	
	@Test
	@EnabledIfEnvironmentVariable(named = "USER", matches = "EFE")
	@DisplayName("Test qui passe si la variable d'environnement USER est EFE")
	void testVArEnv() {
		System.out.println("Var Env");
		
				
	}
	
	@Test
	@EnabledIfSystemProperty(named = "monnaie", matches = "euro")
	void testPropSystem() {
		System.out.println("Prop sys");
	}
	
	
}
