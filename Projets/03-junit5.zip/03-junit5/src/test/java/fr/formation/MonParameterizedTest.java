package fr.formation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

public class MonParameterizedTest {

	
	
	@Test
	void test2EstPair() {
		assertTrue(isPair(2));
	}
	
	@Test
	void test0EstPair() {
		assertTrue(isPair(0));
	}
	
	@Test
	void testMoins2EstPair() {
		assertTrue(isPair(-2));
	}
	
	@Test
	void testAdditionAvecValeursPositives() {
		assertEquals(52, addition(40, 12));
	}
	
	
	@Test
	void testAdditionAvecValeursNegatives() {
		assertEquals(-12, addition(-7, -5));
	}
	
	
	@Test
	void testAdditionAvecValeursNegativesEtPositives() {
		assertEquals(-20, addition(-70, 50));
	}
	
	
	@ParameterizedTest
	@CsvSource(value = {"40,12,52", "-7,-5,-12", "-70,50,-20"})
	void testParametreAddition(int a, int b, int attendu) {
		assertEquals(attendu, addition(a, b));
	}
	
	
	@ParameterizedTest
	// files : relatif a la racine du projet
	// resources : relatif au classpath (fichier dans srrc/test/resources
	@CsvFileSource(resources = "/addition.csv", delimiterString = ";")
	void testParametreExterneAddition(int a, int b, int attendu, boolean test) {
		
		if (test) {
			System.out.println(a);
			assertEquals(attendu, addition(a, b));
		}

	}
	
	
	@ParameterizedTest
	@ValueSource(ints = {0, 2, -2})
	void testParametreIsPair(int valeur) {
		assertTrue(isPair(valeur));
	}
	
	
	public int addition(int a, int b) {
		return a + b;
	}
	
	public boolean isPair(int value) {
		return (value % 2 == 0);
	}
}
