package fr.formation.model;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class AssertAllTest {

	
	
	@Test
	void testRecupPersonne() {
		
		Personne expected = new Personne("Legrand", "Joe", 44);
		Personne actual = recupPersonne();
		
		
		//assertEquals(expected, actual);
		
		assertEquals(expected.getNom(), actual.getNom());
		assertEquals(expected.getPrenom(), actual.getPrenom());
		assertEquals(expected.getAge(), actual.getAge());
		
	}
	
	
	
	@Test
	void testRecupPersonneAvecAssertAll() {
		
		Personne expected = new Personne("Legrand", "Joe", 44);
		Personne actual = recupPersonne();
		
		assertAll(
				() -> assertEquals(expected.getNom(), actual.getNom(), () -> "Nom pas correct"),
				() -> assertEquals(expected.getPrenom(), actual.getPrenom()),
				() -> assertEquals(expected.getAge(), actual.getAge())
		);
		
			
	}
	

	
	public Personne recupPersonne() {
		return new Personne("Legrand", "Joe", 44);
	}
}
