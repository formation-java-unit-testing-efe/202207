package fr.formation.junit4import;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Random;

import org.junit.Ignore;
import org.junit.Test;


public class MesPremiersTest {


	@Test
	public void testQuiNeFaitRien() {
		
		
	}	

	@Test
	public void testQuiNeFaitRienMaisQuiFail() {
		fail("Penser à ecrire ce test");
	}	


	@Test
	@Ignore
	public void testQuiNeFaitRienMaisEstIgnore() {
		
		
	}	
	
	
	@Test
	public void testQuiFait() {
		
		
		// Fail : test qui ne passe pas :
		//    ex : je m'attend à recevoir 10 et je recois 11
		
		// Error : test qui n'a pas été executé correctement
		//	  x : sortie par exception non gérée
		
		
		String s = "abcde";
		
		int longueur = s.length(); // -> NullPointerException
	
		System.out.println("Coucou");
		
		
		assertEquals(5, longueur);
		// assertEquals(longueur, 5); A ne pas faire
	}
	
	
	@Test
	public void testTraitement() {
		String actual = "Toto";
		String attendu = traitement();
		
		assertEquals(attendu, actual);
		// attendu.equals(actual)
		
		// assertEquals(actual, attendu);
		// actual.equals(attendu) -> si actual est null -> NullPointerException
	
	}
	
	
	@Test
	public void testTraitementAvecAssertTrue() {
		String attendu = "Toto";
		String actual = traitement();
		
		assertTrue("Je m'attendais à recevoir " + attendu + " mais j'ai recu " + actual, attendu.equals(actual));

	}

	private String traitement() {
		int val = new Random().nextInt(10);
		if (val % 2 == 0)
			return null;
		else 
			return "Toto";
		
	}
	
	@Test
	public void testIsPairTrueAvec100() {
	
		assertTrue(isPair(100));
	}
	
	@Test
	public void testIsNotPairTrueAvec101() {
	
		assertFalse(isPair(101));
	}
	
	
	private boolean isPair(int valeur) {
		return (valeur % 2 == 0);
	}
	
}
