package fr.formation.jeu;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class JeuTest {

	// test de la méthode jouer()
	
	// Si les joueurs ont le meme resultat
	// Pas de vainqueur apres 5 lancers chacun
	
	// Si gauche a un meilleur resultat que droit -> gauche gagne
	// Si droit a un meilleur resultat que gauche -> droit gagne
	
	
	Jeu jeu;
	Joueur gauche;
	Joueur droit;
	
	@Test
	void testEgalite() {
		De mockDe = Mockito.mock(De.class);
		Mockito.when(mockDe.lancer()).thenReturn(4);
		gauche = new Joueur("gauche", mockDe);
		droit = new Joueur("droit", mockDe);
		
		Joueur spyGauche = Mockito.spy(gauche);
		Joueur spyDroit = Mockito.spy(droit);
		
		jeu = new Jeu(spyGauche, spyDroit);
		Optional<Joueur> optVainqueur = jeu.jouer();
		assertFalse(optVainqueur.isPresent());
		
		// verifier que play() appelé 5 fois sur gauche
		// verifier que play() appelé 5 fois sur droit
		
		Mockito.verify(spyGauche, Mockito.times(5)).play();
		Mockito.verify(spyDroit, Mockito.times(5)).play();
		// OU
		Mockito.verify(mockDe, Mockito.times(20)).lancer();

	}
	
	
	@Test
	void testGaucheGagne() {
		gauche = Mockito.mock(Joueur.class);
		Resultat resG = new Resultat(5);
		Optional<Resultat> optResG = Optional.of(resG);
		Mockito.when(gauche.getLastValue()).thenReturn(optResG);
		
		
		droit = Mockito.mock(Joueur.class);
		Resultat resD = new Resultat(3);
		Optional<Resultat> optResD = Optional.of(resD);
		Mockito.when(droit.getLastValue()).thenReturn(optResD);

		jeu = new Jeu(gauche, droit);
		Optional<Joueur> optVainqueur = jeu.jouer();
		
		assertTrue(optVainqueur.isPresent());
		assertEquals(gauche, optVainqueur.get());
	}
	
	
	@Test
	void testDroitGagne() {
		gauche = Mockito.mock(Joueur.class);
		Resultat resG = new Resultat(2);
		Optional<Resultat> optResG = Optional.of(resG);
		Mockito.when(gauche.getLastValue()).thenReturn(optResG);
		
		
		droit = Mockito.mock(Joueur.class);
		Resultat resD = new Resultat(6);
		Optional<Resultat> optResD = Optional.of(resD);
		Mockito.when(droit.getLastValue()).thenReturn(optResD);

		jeu = new Jeu(gauche, droit);
		Optional<Joueur> optVainqueur = jeu.jouer();
		
		assertTrue(optVainqueur.isPresent());
		assertEquals(droit, optVainqueur.get());
	}
	
	
}
