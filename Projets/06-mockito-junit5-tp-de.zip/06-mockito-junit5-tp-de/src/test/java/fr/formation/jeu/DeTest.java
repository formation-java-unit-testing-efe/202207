package fr.formation.jeu;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
public class DeTest {

	// tester lancer()
	// 1. Verifier que la valeur est comprise entre 1 et 6 (plusieurs fois)
	// 2. Verifier RuntimeException si valeur < 1
	// 3. Verifier RuntimeException si valeur > 6
	// 4. Verifier que toutes les valeurs 1..6 peuvent etre récupérées apres plein de lancers
	// 5. Vérifier que le dé a 6 faces
	
	// Remonter l'information que si rand passé en parametre du constructeur est nul -> marche pas
	

	@Mock
	Random mockRand;
	
	@InjectMocks
	De leDe;

	@Captor
	ArgumentCaptor<Integer> captor;
	
	@RepeatedTest(100)
	@DisplayName("les valeurs doivent être comprises entre 1 et 6")
	void testValeursEntre1Et6() {
		Random r = new Random();
		De leDe = new De(r);
		int value = leDe.lancer();	
		
		assertAll(
				() -> assertTrue(value >= 1),
				() -> assertTrue(value <= 6)
				);
	}
	
	


	@ParameterizedTest
	@ValueSource(ints = {20, -20})
	@DisplayName("Une RuntimeException est levée si valeur < 1 ou valeur > 6")
	void testExceptionSiInf1OuSup6(int valeur) {
	//	Random mockRand = Mockito.mock(Random.class);
	//	De leDe = new De(mockRand);
		Mockito.when(mockRand.nextInt(Mockito.anyInt())).thenReturn(valeur);
		
		RuntimeException re = assertThrows(RuntimeException.class, () -> leDe.lancer());
		assertTrue(re.getMessage().contains("incompatible"));
	}
	
	@Test
	@DisplayName("Toutes les valeurs comprises entre 1 et 6 peuvent être renvoyées")
	void testToutesLesValeursRenvoyees() {
		Set<Integer> set = new HashSet<Integer>();
		Random r = new Random();
		De leDe = new De(r);
		
		for (int i = 0 ; i < 1000 ; i++) {
			set.add(leDe.lancer());
		}
		// Set -> pas de doublon et pas de null
		// set.add(1);
		// set.add(1); -> Je n'aurai qu'un seul 1
		assertEquals(6, set.size()); // -> il y a 6 elements differents dans le set
		// forcément 1,2,3,4,5,6
	}
	
	
	@Test
	@DisplayName("Vérifier que le dé a 6 faces")
	void testLeDeA6Faces() {
		leDe.lancer();
		Mockito.verify(mockRand, Mockito.times(1)).nextInt(captor.capture());
		assertEquals(6, captor.getValue());
	}
	
/*	

	@Test
	@DisplayName("Une RuntimeException est levée si valeur < 1")
	void testExceptionSiInf1() {
	//	Random mockRand = Mockito.mock(Random.class);
	//	De leDe = new De(mockRand);
		Mockito.when(mockRand.nextInt(Mockito.anyInt())).thenReturn(-20);
		
		RuntimeException re = assertThrows(RuntimeException.class, () -> leDe.lancer());
		assertTrue(re.getMessage().contains("incompatible"));
	}
	
	

	@Test
	@DisplayName("Une RuntimeException est levée si valeur > 6")
	void testExceptionSiSup6() {
	//	Random mockRand = Mockito.mock(Random.class);
	//	De leDe = new De(mockRand);
		Mockito.when(mockRand.nextInt(Mockito.anyInt())).thenReturn(20);
		
		RuntimeException re = assertThrows(RuntimeException.class, () -> leDe.lancer());
		assertTrue(re.getMessage().contains("incompatible"));
	}
	*/
}










