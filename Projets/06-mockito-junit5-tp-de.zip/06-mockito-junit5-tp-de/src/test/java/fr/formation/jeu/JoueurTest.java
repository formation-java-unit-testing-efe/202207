package fr.formation.jeu;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class JoueurTest {

	@Mock
	private De mockDe;
	
	private Joueur vraiJoueur;
	
	@BeforeEach
	void setUp() {
		vraiJoueur  = new Joueur("Lebleu", new De(new Random()));
	}
	
	// A tester
	
	// play()
	// 1. Le dé est lancé juste deux fois
	// 2. Si 1er lancer > 2eme -> 1er lancer gardé
	// 3. Si 1er lancer < 2eme -> 2eme lancer gardé
	// 4. Si 1er lancer = 2eme -> 2eme lancer gardé
	
	
	@Test
	void testDeLancer2Fois() {
		Joueur j = new Joueur("Levert", mockDe);
		j.play();
		Mockito.verify(mockDe, Mockito.times(2)).lancer();
	}
	
/*	
	@ParameterizedTest
	@ValueSource(strings = {"5,3,5", "2,4,4", "3,3,3"})
	void testPlayvalueSource(String chaine) {
		String[] tab = chaine.split(",");
		
		Mockito.when(mockDe.lancer()).thenReturn(Integer.parseInt(tab[0]), Integer.parseInt(tab[1]));
		Joueur j = new Joueur("Levert", mockDe);
		j.play();
		
		Resultat res = j.getLastValue().get();
		assertEquals(Integer.parseInt(tab[2]), res.get());
	}	
*/	
	
	
	@ParameterizedTest
	@CsvSource(value = {"5,3,5", "2,4,4", "3,3,3"})
	void testPlay(int a, int b, int attendu) {
		Mockito.when(mockDe.lancer()).thenReturn(a, b);
		Joueur j = new Joueur("Levert", mockDe);
		j.play();
		
		Resultat res = j.getLastValue().get();
		assertEquals(attendu, res.get());
	}
/*
	
	@Test
	void testPlayPremiereValeurPlusGrande() {
		Mockito.when(mockDe.lancer()).thenReturn(5, 3);
		Joueur j = new Joueur("Levert", mockDe);
		j.play();
		
		Resultat res = j.getLastValue().get();
		assertEquals(5, res.get());
	}
	
	@Test
	void testPlayDeuxiemeValeurPlusGrande() {
		Mockito.when(mockDe.lancer()).thenReturn(2, 4);
		Joueur j = new Joueur("Levert", mockDe);
		j.play();
		
		Resultat res = j.getLastValue().get();
		assertEquals(4, res.get());
	}
	
	
	
	
	
	*/
	// getLastValue()
	// A tester pour couverture de code
	
	// Si pas play() -> Optional est vide
	// si play() -> Optional pas vide
	
	// getter -> pas besoin d'avoir des méthodes spécifique
	// verification dans la méthode play() 
	
	
	
	@Test
	void testGetLastValueVideSiPasPlay() {
		assertFalse(vraiJoueur.getLastValue().isPresent());
	}
	
	@Test
	void testGetLastValuePasVideSiPlay() {
		vraiJoueur.play();
		assertTrue(vraiJoueur.getLastValue().isPresent());
	}
}
