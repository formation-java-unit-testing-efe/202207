package fr.formation.jeu;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ResultatTest {

	
	// A tester :
	// compareTo
	// equals
	// get ?
	//   OUI -> 100%, pas un getter
	//   NON -> getter : on retourne toujours valeur (pas de modification possible)
	//   NON -> elle est utilisée dans compareTo et equals
	
	
	private Resultat res5;
	private Resultat res3;
	private Resultat res3bis;
	
	@BeforeEach
	void setUp() {
		res5 = new Resultat(5);
		res3 = new Resultat(3);
		res3bis = new Resultat(3);
	}
	
	@Test
	void testCompareToRenvoieNegatif() {
		assertTrue(res3.compareTo(res5) < 0);
	}
	
	@Test
	void testCompareToRenvoiePositif() {
		assertTrue(res5.compareTo(res3bis) > 0);
	}
	
	@Test
	void testCompareToRenvoie0() {
		assertEquals(0, res3.compareTo(res3bis));
	}
	
	@Test
	void testEqualsMemeObjet() {
		assertTrue(res3.equals(res3));
	}
	
	@Test
	void testEqualsMemeContenu() {
		assertTrue(res3.equals(res3bis));
	}
	
	@Test
	void testEqualsValeursDifferentes() {
		assertFalse(res3.equals(res5));
	}
	
	
	@Test
	void testEqualsAvecString() {
		assertFalse(res3.equals("Hello"));
	}
	
	
	@Test
	void testEqualsNull() {
		assertFalse(res3.equals(null));
	}
	
	
	
}
