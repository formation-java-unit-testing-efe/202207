package fr.formation.tdd;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Calculator {

	public static int add(String s) {

		List<Integer> listeI = parseNombres(s);
		verificationValeursNegatives(listeI);
		return sumOfIntegerList(listeI);
	}

	private static List<Integer> parseNombres(String s) {
		String[] tabS = split(s);
		List<Integer> listeI = stringTableToIntegerList(tabS);
		return listeI;
	}

	private static void verificationValeursNegatives(List<Integer> listeI) {
		String negatives = listeI.stream()
				.filter(val -> val < 0)
				.map(x -> String.valueOf(x))
				.collect(Collectors.joining(", "));

		if (!negatives.isEmpty()) {
			throw new RuntimeException("Negatives Not allowed : " + negatives);
		}
	}

	private static String[] split(String s) {
		
		if (s.length() == 0)
			return new String[0];
		else if (utilisationDeCustomDelimiter(s)) {
			return splitAvecCustomDelimiter(s);
		}else {
			return splitAvecNouvelleLigneEtVirguleDelimiter(s);
		}
	}

	private static boolean utilisationDeCustomDelimiter(String s) {
		return s.startsWith("//");
	}

	private static String[] splitAvecNouvelleLigneEtVirguleDelimiter(String s) {
		String[] tabS = s.split(",|\n");
		return tabS;
	}

	private static String[] splitAvecCustomDelimiter(String s) {
		Matcher m = Pattern.compile("//(.)\n(.*)").matcher(s);
		m.matches();
		String delimiter = m.group(1);
		String numbers = m.group(2);
		return numbers.split(Pattern.quote(delimiter));
	}

	private static Integer sumOfIntegerList(List<Integer> listeI) {
		return listeI.stream()
				  .reduce(0, (a, b) -> a + b);
	}

	private static List<Integer> stringTableToIntegerList(String[] tokens) {
		List<Integer> listeI = Arrays
				.stream(tokens)
				.map(ch -> toInt(ch))
				.collect(Collectors.toList());
		return listeI;
	}

	private static int toInt(String s) {
		return Integer.parseInt(s);
	}
}
