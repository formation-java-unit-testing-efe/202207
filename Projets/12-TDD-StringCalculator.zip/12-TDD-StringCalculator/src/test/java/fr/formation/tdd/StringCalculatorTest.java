package fr.formation.tdd;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

public class StringCalculatorTest {

	
	@Test
	public void doitRenvoyer0SiChaineVide() {
		assertEquals(0, Calculator.add(""));
	}
	
	/*
	 Création de la classe Calculator + ajout de la méthode add
	 
	package fr.formation.tdd;
	
	public class Calculator {
		public static int add(String s) {
			return -562;
		}
	}
	
	// Test fail
		public static int add(String s) {
			return 0;
		}
	 
	// test ok
	 
	 */
	
	
	
	@Test
	public void doitRenvoyer1SiChaine1() {
		assertEquals(1, Calculator.add("1"));
	}
	
	/*
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		return 1;
	}

	*/
	
	@Test
	public void doitRenvoyer2SiChaine2() {
		assertEquals(2, Calculator.add("2"));
	}

	/*
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		return Integer.parseInt(s);
	}
	
	*/
	
	
	@Test
	public void doitRenvoyerSommeDeuxNombresSeparesParVirgule() {
		assertEquals(8, Calculator.add("2,6"));
	}
/*	
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		else if (s.contains(",")) {
			String[] tabS = s.split(",");
			return Integer.parseInt(tabS[0]) + Integer.parseInt(tabS[1]);
		}
		else {
			return Integer.parseInt(s);
		}
	}

	Refactoring
	************
	
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		else if (s.contains(",")) {
			String[] tabS = s.split(",");
			return toInt(tabS[0]) + toInt(tabS[1]);
		}
		else {
			return toInt(s);
		}
	}

	private static int toInt(String s) {
		return Integer.parseInt(s);
	}
*/	

	
	@Test
	public void doitRenvoyer2SommePlusieursNombresSeparesParVirgule() {
		assertEquals(18, Calculator.add("2,6,10"));
	}
/*
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		else if (s.contains(",")) {
			String[] tabS = s.split(",");
			
			List<Integer> listeI = Arrays
					.stream(tabS)
					.map(ch -> toInt(ch))
					.collect(Collectors.toList());
			
			Integer sum = listeI.stream()
					  .reduce(0, (a, b) -> a + b);
			
			return sum;
		}
		else {
			return toInt(s);
		}
	}
	
	Refactoring 1 : Extraction
	************
	
	private static List<Integer> stringTableToIntegerList(String[] tabS) {
		List<Integer> listeI = Arrays
				.stream(tabS)
				.map(ch -> toInt(ch))
				.collect(Collectors.toList());
		return listeI;
	}
	
	
	--> List<Integer> listeI = stringTableToIntegerList(tabS);
	
	
	Refactoring 2 : Extraction
	************
	
	
	private static Integer sumOfIntegerList(List<Integer> listeI) {
		return listeI.stream()
				  .reduce(0, (a, b) -> a + b);
	}

	--> Integer sum = sumOfIntegerList(listeI);
	
	
	Refactoring 3 : 
	************
	
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		else  {
			String[] tabS = s.split(",");
			List<Integer> listeI = stringTableToIntegerList(tabS);
			return sumOfIntegerList(listeI);
		}
	}
	
	*/	
	

	
	@Test
	public void doitAccepterUneNouvelleLigneCommeDelimiterValide() {
		assertEquals(18, Calculator.add("2,6\n10"));
	}

/*

	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		else  {
			String[] tabS = s.split(",|\n");   // <---
			List<Integer> listeI = stringTableToIntegerList(tabS);
			return sumOfIntegerList(listeI);
		}
	}

	Refactoring : Extraction
	************

	private static String[] split(String s) {
		String[] tabS = s.split(",|\n");
		return tabS;
	}

	--> String[] tabS = split(s);


*/
	
	

	
	@Test
	public void doitAccepterDelimiterCustom() {
		assertEquals(7, Calculator.add("//;\n2;5"));
	}
	
/*	
	private static String[] split(String s) {
		if (s.startsWith("//")) {
			Matcher m = Pattern.compile("//(.)\n(.*)").matcher(s);
			m.matches();
			String delimiter = m.group(1);
			String numbers = m.group(2);
			return numbers.split(delimiter);
		}
		String[] tabS = s.split(",|\n");
		return tabS;
	}

	Refactoring 1 : Extraction
	************

	private static String[] splitAvecCustomDelimiter(String s) {
		Matcher m = Pattern.compile("//(.)\n(.*)").matcher(s);
		m.matches();
		String delimiter = m.group(1);
		String numbers = m.group(2);
		return numbers.split(delimiter);
	}


	-->
	if (s.startsWith("//")) {
			return splitAvecCustomDelimiter(s);
	}
	
	

	Refactoring 2 : Extraction
	************

	private static String[] splitAvecNouvelleLigneEtVirguleDelimiter(String s) {
		String[] tabS = s.split(",|\n");
		return tabS;
	}


	-->
		if (s.startsWith("//")) {
			return splitAvecCustomDelimiter(s);
		}else {
			return splitAvecNouvelleLigneEtVirguleDelimiter(s);
		}

	Refactoring 3 : Extraction
	************
	
	
	private static boolean utilisationDeCustomDelimiter(String s) {
		return s.startsWith("//");
	}

	--> dans split()
		if (utilisationDeCustomDelimiter(s)) {
			return splitAvecCustomDelimiter(s);
		}else {
			return splitAvecNouvelleLigneEtVirguleDelimiter(s);
		}

*/	
	
	

	
	@Test
	public void doitAccepterDelimiterCustomCaracteresSpeciaux() {
		assertEquals(7, Calculator.add("//.\n2.5"));
	}

/*
 
	private static String[] splitAvecCustomDelimiter(String s) {
		Matcher m = Pattern.compile("//(.)\n(.*)").matcher(s);
		m.matches();
		String delimiter = m.group(1);
		String numbers = m.group(2);
		return numbers.split(Pattern.quote(delimiter));   <---
	}
 	
 	
 */
	
	

	
	@Test
	public void doitRenvoyerExceptionSiValeursNegatives() {
		assertThrows(RuntimeException.class, () -> Calculator.add("-2,6,10"));
	}

/*	
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		else  {
			String[] tabS = split(s);
			List<Integer> listeI = stringTableToIntegerList(tabS);
			
			boolean isNegative = listeI.stream()
		            .anyMatch(t -> t < 0);
			
			if (isNegative) {
				throw new RuntimeException();
			}
			return sumOfIntegerList(listeI);
		}
	}

*/	
	
	
	@Test
	public void doitRenvoyerExceptionAvecValeurNegativeEnMessage() {
		try {
			Calculator.add("-2,6,10");
			fail("Exception expected");
		} catch (Exception e) {
			assertEquals("Negatives Not allowed : -2", e.getMessage());
		}
	}
/*	
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		else  {
			String[] tabS = split(s);
			List<Integer> listeI = stringTableToIntegerList(tabS);
			
//			boolean isNegative = listeI.stream()
//		            .anyMatch(t -> t < 0);
			
			List<Integer> listeNegatives = listeI.stream()
					.filter(val -> val < 0)
					.collect(Collectors.toList());
			
			
			if (listeNegatives.size() > 0) {
				throw new RuntimeException("Negatives Not allowed : " + listeNegatives.get(0));
			}
			return sumOfIntegerList(listeI);
		}
	}

*/	
	
	
	
	@Test
	public void doitRenvoyerExceptionAvecToutesLesValeursNegativesEnMessage() {
		try {
			Calculator.add("-2,-6,4,3,-10");
			fail("Exception expected");
		} catch (Exception e) {
			assertEquals("Negatives Not allowed : -2, -6, -10", e.getMessage());
		}
	}
	
/*	
	public static int add(String s) {
		if (s.length() == 0)
			return 0;
		else  {
			String[] tabS = split(s);
			List<Integer> listeI = stringTableToIntegerList(tabS);
			
			String negatives = listeI.stream()
					.filter(val -> val < 0)
					.map(x -> String.valueOf(x))
					.collect(Collectors.joining(", "));

			if (!negatives.isEmpty()) {
				throw new RuntimeException("Negatives Not allowed : " + negatives);
			}
			return sumOfIntegerList(listeI);
		}
	}



	Refactoring  : Extraction
	************
	


	private static void verificationValeursNegatives(List<Integer> listeI) {
		String negatives = listeI.stream()
				.filter(val -> val < 0)
				.map(x -> String.valueOf(x))
				.collect(Collectors.joining(", "));

		if (!negatives.isEmpty()) {
			throw new RuntimeException("Negatives Not allowed : " + negatives);
		}
	}



	Refactoring  : Réécriture
	************
	
	private static String[] split(String s) {
		
		if (s.length() == 0)    <---
			return new String[0];
		else if (utilisationDeCustomDelimiter(s)) {
			return splitAvecCustomDelimiter(s);
		}else {
			return splitAvecNouvelleLigneEtVirguleDelimiter(s);
		}
	}


	-->
	
	public static int add(String s) {

		String[] tabS = split(s);
		List<Integer> listeI = stringTableToIntegerList(tabS);

		verificationValeursNegatives(listeI);
		return sumOfIntegerList(listeI);
	}
	
	
	
	Refactoring  : Extraction
	************

	private static List<Integer> parseNombres(String s) {
		String[] tabS = split(s);
		List<Integer> listeI = stringTableToIntegerList(tabS);
		return listeI;
	}

	-->
	
	public static int add(String s) {

		List<Integer> listeI = parseNombres(s);
		verificationValeursNegatives(listeI);
		return sumOfIntegerList(listeI);
	}
	


*/	
	
	
	
}
