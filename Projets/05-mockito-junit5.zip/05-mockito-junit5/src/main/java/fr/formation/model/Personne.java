package fr.formation.model;

public class Personne {

	public String nom;
}
