package fr.formation.service;

import fr.formation.model.Personne;

public class PersonneService {

	PersonneDao pDao;
	
	public PersonneService(PersonneDao pDao) {
		this.pDao = pDao;
	}
	
	public void ajoutPersonne(Personne p) throws Exception {
		testPersonne(p);
		
		
		pdao.save(p);
	}

	public void testPersonne(Personne p) throws Exception {
		if (p == null ) throw new Exception();
		if (p.nom == null || p.nom.trim().isEmpty()) throw new Exception();
	}
}
