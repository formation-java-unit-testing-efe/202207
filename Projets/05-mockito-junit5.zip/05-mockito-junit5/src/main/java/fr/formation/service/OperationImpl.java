package fr.formation.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class OperationImpl implements Operation{

	@Override
	public int addition(int a, int b) {
		return a + b;
	}

	@Override
	public int soustraction(int a, int b) {
		return a - b;
	}

	@Override
	public int multiplication(int a, int b) {
		return a * b;
	}

	@Override
	public int division(int a, int b) throws RuntimeException {
		if (b == 0)
			throw new RuntimeException("Dicision par zero");
		return a / b;
	}

	@Override
	public int getRandomInt() {
		return new Random().nextInt(100);
	}

	@Override
	public List<Integer> getRandomIntList(int qte) {
		List<Integer> listeI = new ArrayList<Integer>();
		for (int i = 0 ; i < qte ; i++) {
			listeI.add( getRandomInt());
		}
		return listeI;
	}

}
