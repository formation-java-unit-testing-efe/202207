package fr.formation.service;

public class Traitement {

	private Operation op;

	public Traitement(Operation op) {
		this.op = op;
	}
	
	
	public int addition2plus2() {
		return op.addition(2, 2);
	}
}
