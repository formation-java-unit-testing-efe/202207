package fr.formation.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
public class OperationTest {

	@InjectMocks
	Traitement traitement;
	
	@Mock
	Operation operation;
	
	@Test
	void testCreationMock() {
		Operation op = Mockito.mock(Operation.class);
		System.out.println(op);
	}
	
	@Test
	void testCreationMockAvecToString() {
		Operation op = Mockito.mock(Operation.class, "Mock de Operation");
		System.out.println(op);
	}
	
	
	@Test
	void testInjectionMock() {
		System.out.println(operation);
	}
	
	@Test
	void testAddition() {
		assertEquals(0, operation.addition(4, 3));
	}
	
	@Test
	void testDivisionParZero() {
		assertEquals(0, operation.division(0, 0));
	}
	
	
	@Test
	void testAdditionAvecStubbing() {
		
		Mockito.when(operation.addition(4, 3)).thenReturn(7);
		Mockito.when(operation.addition(3, 4)).thenReturn(7);
		
		assertEquals(7, operation.addition(4, 3));
		assertEquals(7, operation.addition(4, 3));
		assertEquals(7, operation.addition(4, 3));

		assertEquals(7, operation.addition(3, 4));   // fail
		
	}
	
	@Test
	void testDivisionZeroParZeroAvecStubbing() {
		Mockito.when(operation.division(0, 0)).thenThrow(ArithmeticException.class);
		
		assertThrows(ArithmeticException.class, () -> operation.division(0, 0));
	}

	
	@Test
	void testDivisionParZeroAvecStubbing() {
		Mockito.when(operation.division(Mockito.anyInt(), Mockito.eq(0))).thenThrow(ArithmeticException.class);
		
		assertThrows(ArithmeticException.class, () -> operation.division(0, 0));
		assertThrows(ArithmeticException.class, () -> operation.division(10, 0));
		assertThrows(ArithmeticException.class, () -> operation.division(-10, 0));
		assertThrows(ArithmeticException.class, () -> operation.division(523, 0));
	}

	
	@Test
	void testTraitement() {
		Mockito.when(operation.addition(2, 2)).thenReturn(4);
		
		int resultat = traitement.addition2plus2();
		assertEquals(4, resultat);
		
		// Vérifier que addition2plus2 appelle op.addition(2, 2)
		
		Mockito.verify(operation, Mockito.times(1)).addition(2, 2);
	}
	
	@Test
	void testGetRandomInt() {
		Mockito.when(operation.getRandomInt()).thenReturn(4, -1, 0, 9, 321, -12);
		assertEquals(4, operation.getRandomInt());
		assertEquals(-1, operation.getRandomInt());
		assertEquals(0, operation.getRandomInt());
		assertEquals(9, operation.getRandomInt());
		assertEquals(321, operation.getRandomInt());
		assertEquals(-12, operation.getRandomInt());
		assertEquals(-12, operation.getRandomInt());
		assertEquals(-12, operation.getRandomInt());
		assertEquals(-12, operation.getRandomInt());
		assertEquals(-12, operation.getRandomInt());
	}
	

	@Test
	void testGetRandomIntList() {
		Operation op = new OperationImpl();
		// Mockito doit verifier qu'un vrai objet a bien appelé une méthode
		// Mockito : espionne ce vrai objet
		
		Operation spy = Mockito.spy(op);
		
		 List<Integer> liste = spy.getRandomIntList(10);
		 
		 assertEquals(10, liste.size());
		 
		 Mockito.verify(spy, Mockito.times(10)).getRandomInt();
		 Mockito.verify(spy, Mockito.never()).addition(4, 3);
		 
	}

	
}
