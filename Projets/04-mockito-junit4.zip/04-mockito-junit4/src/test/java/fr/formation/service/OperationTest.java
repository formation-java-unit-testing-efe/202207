package fr.formation.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.class)
public class OperationTest {

	
	@Mock
	Operation operation;
	
	@Test
	public void testCreationMock() {
		Operation op = Mockito.mock(Operation.class);
		System.out.println(op);
	}
	
	@Test
	public void testCreationMockAvecToString() {
		Operation op = Mockito.mock(Operation.class, "Mock de Operation");
		System.out.println(op);
	}
	
	
	@Test
	public void testInjectionMock() {
		System.out.println(operation);
	}
}
