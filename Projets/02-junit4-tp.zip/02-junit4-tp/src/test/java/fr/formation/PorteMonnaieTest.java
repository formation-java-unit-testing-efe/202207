	package fr.formation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.util.HashMap;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PorteMonnaieTest {
	
	
	private PorteMonnaie pm;
	private SommeArgent sa1;
	private SommeArgent sa2;
	
	private PorteMonnaie expected;
	private SommeArgent laSommeTotale;
	
	
	@Before
	public void setUp() {
		pm = new PorteMonnaie();
		sa1 = new SommeArgent(5, "EUR");
		sa2 = new SommeArgent(5, "EUR");
		pm.ajouteSomme(sa1);
		pm.ajouteSomme(sa2);
		expected = new PorteMonnaie();
		laSommeTotale = new SommeArgent(10, "EUR");
		expected.ajouteSomme(laSommeTotale);
	}
	
	@Test
	public void testPorteMonnaieEgaux() {
		
		Assert.assertTrue(expected.equals(pm));
		assertEquals(expected, pm);
	}
	
	@Test
	public void testAjoutSomme() {
		HashMap<String, Integer> contenu = expected.getContenu();
		int euros = contenu.get("EUR");
		
		Assert.assertEquals(10, euros);
		Assert.assertEquals(expected, pm);
	}

	@Test
	public void testPorteMonnaiePasEgaux() {
		SommeArgent sa3 = new SommeArgent(2, "USD");
		pm.ajouteSomme(sa3); 
		
		Assert.assertFalse(expected.equals(pm));
		assertThat(pm, CoreMatchers.not(expected));
	}

}
