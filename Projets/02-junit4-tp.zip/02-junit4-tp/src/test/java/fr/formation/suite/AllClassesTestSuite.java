package fr.formation.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import fr.formation.PorteMonnaieTest;
import fr.formation.SommeArgentTest;

@RunWith(Suite.class)
@SuiteClasses({
	SommeArgentTest.class,
	PorteMonnaieTest.class
})
public class AllClassesTestSuite {

}
